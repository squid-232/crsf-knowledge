/**
 * test_crsf.c - unit tests / test vectors for crsf.c
 * build & run:  gcc -std=c99 -Wall -Wextra -pedantic crsf.c test_crsf.c -o test_crsf && ./test_crsf
 */
#include "crsf.h"

#include <stdio.h>
#include <string.h>

static int g_pass, g_fail;
#define CHECK(c) do { if (c) g_pass++; else { g_fail++; \
    printf("  FAIL line %d: %s\n", __LINE__, #c); } } while (0)

static void dump(const char *name, const uint8_t *f, size_t n)
{
    size_t i;
    printf("  %-26s", name);
    for (i = 0; i < n; i++) printf(" %02X", f[i]);
    printf("\n");
}

static void check_bytes(const char *name, const uint8_t *got, size_t got_n,
                        const uint8_t *exp, size_t exp_n)
{
    dump(name, got, got_n);
    CHECK(got_n == exp_n && memcmp(got, exp, exp_n) == 0);
    CHECK(crsf_frame_check(got, got_n));
}

/* -------------------------------------------------------- test vectors */
static const uint8_t V_RC_MID[] = { 0xC8,0x18,0x16,0xE0,0x03,0x1F,0xF8,0xC0,0x07,0x3E,0xF0,0x81,
    0x0F,0x7C,0xE0,0x03,0x1F,0xF8,0xC0,0x07,0x3E,0xF0,0x81,0x0F,0x7C,0xAD };
static const uint8_t V_RC_CH3_CH5_MIN[] = { 0xC8,0x18,0x16,0xE0,0x03,0x1F,0x2B,0xC0,0xC7,0x0A,0xF0,
    0x81,0x0F,0x7C,0xE0,0x03,0x1F,0xF8,0xC0,0x07,0x3E,0xF0,0x81,0x0F,0x7C,0x45 };
static const uint8_t V_PING[]  = { 0xC8,0x04,0x28,0x00,0xEA,0x54 };
static const uint8_t V_BATT[]  = { 0xC8,0x0A,0x08,0x00,0xA8,0x00,0x7B,0x00,0x04,0xD2,0x38,0x09 };
static const uint8_t V_LINK[]  = { 0xC8,0x0C,0x14,0x3C,0x3E,0x64,0x09,0x00,0x07,0x03,0x37,0x64,0x0A,0xDF };
static const uint8_t V_FMODE[] = { 0xC8,0x07,0x21,0x41,0x43,0x52,0x4F,0x00,0x80 };
static const uint8_t V_PREAD[] = { 0xEE,0x06,0x2C,0xEE,0xEA,0x01,0x00,0x86 };
static const uint8_t V_BIND[]  = { 0xC8,0x07,0x32,0xEC,0xC8,0x10,0x01,0x9E,0xE8 };
static const uint8_t V_SPEC_CMD[] = { 0xC8,0x07,0x32,0xEE,0x13,0x13,0x01,0x66,0x06 };

static void fill(uint16_t ch[16], uint16_t v) { int i; for (i = 0; i < 16; i++) ch[i] = v; }

static void test_crc(void)
{
    printf("[crc]\n");
    CHECK(crsf_crc8(&V_RC_MID[2], sizeof(V_RC_MID) - 3u) == 0xAD);
    CHECK(crsf_crc8_cmd(&V_BIND[2], 5) == 0x9E);       /* 32 EC C8 10 01 */
    CHECK(crsf_crc8_cmd(&V_SPEC_CMD[2], 5) == 0x66);   /* 32 EE 13 13 01 */
    CHECK(crsf_frame_check(V_LINK, sizeof(V_LINK)));
    CHECK(!crsf_frame_check(V_LINK, sizeof(V_LINK) - 1u));
}

static void test_channels(void)
{
    uint16_t ch[16], back[16];
    uint8_t f[CRSF_FRAME_SIZE_MAX], n, packed[22];
    uint32_t seed = 12345u;
    int i, k, ok = 1;

    printf("[rc channels]\n");
    fill(ch, CRSF_CH_MID);
    n = crsf_encode_rc_channels(f, CRSF_SYNC_BYTE, ch);
    check_bytes("RC all 992 (1500us)", f, n, V_RC_MID, sizeof(V_RC_MID));

    ch[2] = CRSF_CH_MIN;                     /* CH3 (throttle) */
    ch[4] = CRSF_CH_MIN;                     /* CH5 (AUX1, arm) */
    n = crsf_encode_rc_channels(f, CRSF_SYNC_BYTE, ch);
    check_bytes("RC CH3=CH5=172", f, n, V_RC_CH3_CH5_MIN, sizeof(V_RC_CH3_CH5_MIN));

    CHECK(crsf_decode_rc_channels(V_RC_CH3_CH5_MIN, back));
    CHECK(back[0] == 992 && back[2] == 172 && back[4] == 172 && back[15] == 992);

    for (k = 0; k < 1000; k++) {             /* random round trip */
        for (i = 0; i < 16; i++) {
            seed = seed * 1103515245u + 12345u;
            ch[i] = (uint16_t)((seed >> 16) & 0x7FFu);
        }
        crsf_pack_channels(ch, packed);
        crsf_unpack_channels(packed, back);
        if (memcmp(ch, back, sizeof(ch)) != 0) ok = 0;
    }
    CHECK(ok);

    /* ticks <-> microseconds (TBS spec formulas) */
    CHECK(CRSF_TICKS_TO_US(172) == 988);
    CHECK(CRSF_TICKS_TO_US(992) == 1500);
    CHECK(CRSF_TICKS_TO_US(1811) == 2011);
    CHECK(CRSF_US_TO_TICKS(1000) == 192);
    CHECK(CRSF_US_TO_TICKS(1500) == 992);
    CHECK(CRSF_US_TO_TICKS(2000) == 1792);

    /* frames longer than expected must be accepted (e.g. ELRS 4.x armStatus) */
    memcpy(packed, &V_RC_MID[3], 22);
    {
        uint8_t p23[23];
        memcpy(p23, packed, 22);
        p23[22] = 0x01;
        n = crsf_encode_frame(f, CRSF_SYNC_BYTE, CRSF_TYPE_RC_CHANNELS, p23, 23);
        CHECK(n == 27 && crsf_decode_rc_channels(f, back) && back[7] == 992);
    }
}

static void test_telemetry(void)
{
    uint8_t f[CRSF_FRAME_SIZE_MAX], n;
    crsf_battery_t bat = { 168, 123, 1234, 56 }, bat2;
    crsf_link_stats_t ls = { 60, 62, 100, 9, 0, 7, 3, 55, 100, 10 }, ls2;

    printf("[telemetry]\n");
    n = crsf_encode_battery(f, &bat);
    check_bytes("battery 16.8V 12.3A", f, n, V_BATT, sizeof(V_BATT));
    CHECK(crsf_decode_battery(f, &bat2) && bat2.voltage_dv == 168 &&
          bat2.current_da == 123 && bat2.capacity_mah == 1234 && bat2.remaining == 56);

    n = crsf_encode_link_stats(f, &ls);
    check_bytes("link statistics", f, n, V_LINK, sizeof(V_LINK));
    CHECK(crsf_decode_link_stats(V_LINK, &ls2));
    CHECK(ls2.up_rssi_ant1 == 60 && ls2.up_lq == 100 && ls2.up_snr == 9 &&
          ls2.rf_profile == 7 && ls2.down_rssi == 55 && ls2.down_snr == 10);
    CHECK(crsf_rf_power_mw(ls2.up_rf_power) == 100);
    CHECK(crsf_rf_power_mw(7) == 250 && crsf_rf_power_mw(8) == 50 && crsf_rf_power_mw(99) == 0);

    n = crsf_encode_flight_mode(f, "ACRO");
    check_bytes("flight mode \"ACRO\"", f, n, V_FMODE, sizeof(V_FMODE));

    {
        crsf_gps_t g = { 311234567, 1214567890, 523, 9000, 15, 12 };
        n = crsf_encode_gps(f, &g);
        dump("GPS (31.12N 121.45E)", f, n);
        CHECK(n == 19 && crsf_frame_check(f, n) && f[1] == 17);
        CHECK(f[15] == 0x03 && f[16] == 0xF7);        /* 15 m + 1000 = 0x03F7 */
    }
    n = crsf_encode_attitude(f, 1745, -873, 31416);   /* 10 deg, -5 deg, 180 deg */
    dump("attitude", f, n);
    CHECK(n == 10 && crsf_frame_check(f, n));
    n = crsf_encode_vario(f, -150);
    dump("vario -1.5 m/s", f, n);
    CHECK(n == 6 && f[3] == 0xFF && f[4] == 0x6A && crsf_frame_check(f, n));
}

static void test_extended(void)
{
    uint8_t f[CRSF_FRAME_SIZE_MAX], n, sub = 0x01;
    printf("[extended frames]\n");
    n = crsf_encode_ping(f, CRSF_SYNC_BYTE, CRSF_ADDR_BROADCAST, CRSF_ADDR_RADIO);
    check_bytes("ping (radio -> all)", f, n, V_PING, sizeof(V_PING));
    n = crsf_encode_param_read(f, CRSF_ADDR_TX, CRSF_ADDR_TX, CRSF_ADDR_RADIO, 1, 0);
    check_bytes("param read #1 chunk 0", f, n, V_PREAD, sizeof(V_PREAD));
    n = crsf_encode_command(f, CRSF_SYNC_BYTE, CRSF_ADDR_RX, CRSF_ADDR_FC,
                            CRSF_CMD_CROSSFIRE, &sub, 1);
    check_bytes("command: bind (FC -> RX)", f, n, V_BIND, sizeof(V_BIND));
    n = crsf_encode_command(f, CRSF_SYNC_BYTE, CRSF_ADDR_TX, 0x13, 0x13, &sub, 1);
    check_bytes("command: spec example", f, n, V_SPEC_CMD, sizeof(V_SPEC_CMD));
    CHECK(CRSF_IS_EXTENDED(CRSF_TYPE_PING) && !CRSF_IS_EXTENDED(CRSF_TYPE_RC_CHANNELS));
    CHECK(!CRSF_IS_EXTENDED(0x34) && !CRSF_IS_EXTENDED(0x80) && !CRSF_IS_EXTENDED(0xAA) &&
          CRSF_IS_EXTENDED(CRSF_TYPE_MSP_RESP));
}

/* --------------------------------------------------------- parser tests */
typedef struct { uint8_t type[32]; int n; crsf_device_info_t info; int has_info; } capture_t;

static void on_frame(void *user, const uint8_t *f, uint8_t len)
{
    capture_t *c = (capture_t *)user;
    CHECK(crsf_frame_check(f, len));
    if (c->n < 32) c->type[c->n++] = crsf_frame_type(f);
    if (crsf_frame_type(f) == CRSF_TYPE_DEVICE_INFO)
        c->has_info = crsf_decode_device_info(f, &c->info);
}

static size_t append(uint8_t *s, size_t n, const uint8_t *d, size_t len)
{
    memcpy(&s[n], d, len);
    return n + len;
}

static void test_parser_noisy(void)
{
    static const uint8_t junk1[] = { 0x00, 0xC8, 0xFF, 0x55, 0xC8, 0x01, 0xAA, 0xC8 };
    static const uint8_t junk2[] = { 0xC8, 0x3C };      /* false sync, len 60 */
    static const uint8_t expect[] = { 0x16, 0x14, 0x08, 0x21, 0x16, 0x16, 0x16 };
    uint8_t s[512], bad[sizeof(V_RC_MID)];
    size_t n = 0, i = 0;
    uint32_t t = 0, seed = 7u;
    crsf_parser_t p;
    capture_t c;

    printf("[parser: noisy stream]\n");
    memset(&c, 0, sizeof(c));
    memcpy(bad, V_RC_MID, sizeof(bad));
    bad[10] ^= 0x01;                                    /* corrupt one bit */

    n = append(s, n, junk1, sizeof(junk1));
    n = append(s, n, V_RC_MID, sizeof(V_RC_MID));       /* ok 0x16 */
    n = append(s, n, V_LINK, sizeof(V_LINK));           /* ok 0x14 */
    n = append(s, n, bad, sizeof(bad));                 /* CRC error */
    n = append(s, n, junk2, sizeof(junk2));             /* swallows next bytes */
    n = append(s, n, V_BATT, sizeof(V_BATT));           /* ok 0x08 (recovered) */
    n = append(s, n, V_FMODE, sizeof(V_FMODE));         /* ok 0x21 (recovered) */
    n = append(s, n, V_RC_MID, sizeof(V_RC_MID));       /* ok 0x16 */
    n = append(s, n, V_RC_CH3_CH5_MIN, sizeof(V_RC_CH3_CH5_MIN));
    n = append(s, n, V_RC_MID, sizeof(V_RC_MID));

    crsf_parser_init(&p, CRSF_BAUD_ELRS_RX, on_frame, &c);
    while (i < n) {                                     /* random chunk sizes */
        size_t chunk;
        seed = seed * 1103515245u + 12345u;
        chunk = 1u + ((seed >> 16) % 17u);
        if (chunk > n - i) chunk = n - i;
        crsf_parser_feed(&p, &s[i], chunk, t);
        i += chunk;
        t += 20u;                                       /* no timeouts here */
    }
    printf("  frames_ok=%lu crc_errors=%lu len_errors=%lu timeouts=%lu\n",
           (unsigned long)p.frames_ok, (unsigned long)p.crc_errors,
           (unsigned long)p.len_errors, (unsigned long)p.timeouts);
    CHECK(c.n == (int)sizeof(expect) && memcmp(c.type, expect, sizeof(expect)) == 0);
    CHECK(p.crc_errors >= 2u && p.len_errors >= 3u && p.timeouts == 0u);
}

static void test_parser_timeout(void)
{
    crsf_parser_t p;
    capture_t c;
    printf("[parser: timeouts]\n");

    /* 1) truncated frame, pause, then a complete frame */
    memset(&c, 0, sizeof(c));
    crsf_parser_init(&p, CRSF_BAUD_ELRS_RX, on_frame, &c);
    CHECK(p.timeout_us == 1752u);
    crsf_parser_feed(&p, V_RC_MID, 5, 0);
    crsf_parser_feed(&p, V_RC_MID, sizeof(V_RC_MID), 4000);
    CHECK(c.n == 1 && p.timeouts == 1u && p.crc_errors == 0u);

    /* 2) false sync swallows a real frame; the timeout salvages it */
    memset(&c, 0, sizeof(c));
    crsf_parser_init(&p, CRSF_BAUD_ELRS_RX, on_frame, &c);
    crsf_parser_feed(&p, (const uint8_t *)"\xC8\x3C", 2, 0);
    crsf_parser_feed(&p, V_BATT, sizeof(V_BATT), 0);
    crsf_parser_feed(&p, V_FMODE, sizeof(V_FMODE), 5000);
    CHECK(c.n == 2 && c.type[0] == CRSF_TYPE_BATTERY && c.type[1] == CRSF_TYPE_FLIGHT_MODE);
    printf("  frames_ok=%lu timeouts=%lu\n", (unsigned long)p.frames_ok,
           (unsigned long)p.timeouts);
}

static void test_device_info(void)
{
    crsf_device_info_t info;
    uint8_t f[CRSF_FRAME_SIZE_MAX], n, ping[8], pn;
    crsf_parser_t p;
    capture_t c;

    printf("[device discovery]\n");
    memset(&info, 0, sizeof(info));
    strcpy(info.name, "ELRS RX");
    info.serial = 0x454C5253u;                         /* 'E''L''R''S' */
    info.hw_id = 0;
    info.fw_id = 0x00040100u;
    info.param_count = 12;
    info.param_version = 0;

    /* handset pings everybody, receiver answers to the handset (0xEA) */
    pn = crsf_encode_ping(ping, CRSF_ADDR_TX, CRSF_ADDR_BROADCAST, CRSF_ADDR_RADIO);
    dump("ping (0xEE sync)", ping, pn);
    n = crsf_encode_device_info(f, CRSF_ADDR_RADIO, CRSF_ADDR_RADIO, CRSF_ADDR_RX, &info);
    dump("device info", f, n);

    memset(&c, 0, sizeof(c));
    crsf_parser_init(&p, CRSF_BAUD_HANDSET, on_frame, &c);
    crsf_parser_feed(&p, f, n, 0);                     /* 0xEA not accepted yet */
    CHECK(c.n == 0);
    crsf_parser_accept(&p, CRSF_ADDR_RADIO);
    crsf_parser_feed(&p, f, n, 100);
    CHECK(c.n == 1 && c.has_info);
    CHECK(strcmp(c.info.name, "ELRS RX") == 0 && c.info.serial == 0x454C5253u &&
          c.info.fw_id == 0x00040100u && c.info.param_count == 12);
    printf("  name=\"%s\" serial=0x%08lX -> %s\n", c.info.name, (unsigned long)c.info.serial,
           c.info.serial == 0x454C5253u ? "ExpressLRS device" : "other device");
}

int main(void)
{
    test_crc();
    test_channels();
    test_telemetry();
    test_extended();
    test_parser_noisy();
    test_parser_timeout();
    test_device_info();
    printf("\n%d checks passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
