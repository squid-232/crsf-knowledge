/**
 * crsf.c - Minimal, portable CRSF library (see crsf.h)
 * License: MIT
 */
#include "crsf.h"

#include <string.h>

/* =================================================================== CRC */
static uint8_t crc8_calc(const uint8_t *d, size_t n, uint8_t poly)
{
    uint8_t crc = 0;
    while (n--) {
        uint8_t i;
        crc ^= *d++;
        for (i = 0; i < 8u; i++) {
            if (crc & 0x80u) crc = (uint8_t)((crc << 1) ^ poly);
            else             crc = (uint8_t)(crc << 1);
        }
    }
    return crc;
}

/* CRC-8/DVB-S2. A 256 byte lookup table (see the spec) is faster if needed. */
uint8_t crsf_crc8(const uint8_t *data, size_t len)     { return crc8_calc(data, len, 0xD5u); }
uint8_t crsf_crc8_cmd(const uint8_t *data, size_t len) { return crc8_calc(data, len, 0xBAu); }

bool crsf_frame_check(const uint8_t *f, size_t n)
{
    uint8_t len;
    if (n < 4u) return false;
    len = f[1];
    if (len < CRSF_LEN_MIN || len > CRSF_LEN_MAX || (size_t)len + 2u != n) return false;
    return crsf_crc8(&f[2], (size_t)len - 1u) == f[n - 1u];
}

/* ================================================================ parser */
static bool is_sync(const crsf_parser_t *p, uint8_t b)
{
    return (((unsigned)p->sync_map[b >> 3] >> (b & 7u)) & 1u) != 0u;
}

void crsf_parser_accept(crsf_parser_t *p, uint8_t sync)
{
    p->sync_map[sync >> 3] |= (uint8_t)(1u << (sync & 7u));
}

void crsf_parser_init(crsf_parser_t *p, uint32_t baud, crsf_frame_cb_t cb, void *user)
{
    memset(p, 0, sizeof(*p));
    if (baud == 0u) baud = CRSF_BAUD_ELRS_RX;
    /* air time of a maximum frame (64 bytes * 10 bit, 8N1) + 15 % margin:
     * 420000 baud -> 1752 us, 400000 baud -> 1840 us */
    p->timeout_us = (uint32_t)((uint64_t)CRSF_FRAME_SIZE_MAX * 10u * 1150000u / baud);
    p->on_frame = cb;
    p->user = user;
    crsf_parser_accept(p, CRSF_SYNC_BYTE);
}

static void drop(crsf_parser_t *p, uint8_t n)
{
    if (n >= p->pos) { p->pos = 0; return; }
    memmove(p->buf, p->buf + n, (size_t)(p->pos - n));
    p->pos = (uint8_t)(p->pos - n);
}

/* Extract as many frames as possible from buf[]. Returns when the buffer is
 * empty or holds a plausible but still incomplete frame. On any error only
 * ONE byte is dropped, so a real frame hidden behind a false sync byte is
 * found again (resync without losing data). */
static void scan(crsf_parser_t *p)
{
    while (p->pos > 0u) {
        uint8_t len, total;
        if (!is_sync(p, p->buf[0])) {                 /* hunt for a sync byte */
            uint8_t i = 1;
            while (i < p->pos && !is_sync(p, p->buf[i])) i++;
            drop(p, i);
            continue;
        }
        if (p->pos < 2u) return;                      /* need the len byte   */
        len = p->buf[1];
        if (len < CRSF_LEN_MIN || len > CRSF_LEN_MAX) {
            p->len_errors++;
            drop(p, 1);
            continue;
        }
        total = (uint8_t)(len + 2u);
        if (p->pos < total) return;                   /* need more bytes     */
        if (crsf_crc8(&p->buf[2], (size_t)len - 1u) == p->buf[total - 1u]) {
            p->frames_ok++;
            if (p->on_frame) p->on_frame(p->user, p->buf, total);
            drop(p, total);
        } else {
            p->crc_errors++;
            drop(p, 1);
        }
    }
}

void crsf_parser_feed(crsf_parser_t *p, const uint8_t *data, size_t len, uint32_t now_us)
{
    size_t i;
    for (i = 0; i < len; i++) {
        uint8_t before;
        if (p->pos > 0u && p->timeout_us != 0u &&
            (uint32_t)(now_us - p->frame_start_us) > p->timeout_us) {
            /* stale partial frame: salvage complete frames, drop the rest */
            p->timeouts++;
            while (p->pos > 0u) { drop(p, 1); scan(p); }
        }
        if (p->pos == 0u) {
            if (!is_sync(p, data[i])) continue;       /* idle: wait for sync */
            p->frame_start_us = now_us;
        }
        p->buf[p->pos++] = data[i];
        before = p->pos;
        scan(p);
        if (p->pos > 0u && p->pos < before)           /* resynced mid-buffer */
            p->frame_start_us = now_us;
    }
}

/* =========================================================== RC channels */
void crsf_pack_channels(const uint16_t ch[16], uint8_t out[22])
{
    uint32_t bits = 0;
    uint8_t nbits = 0, o = 0, i;
    for (i = 0; i < CRSF_NUM_CHANNELS; i++) {
        bits |= (uint32_t)(ch[i] & 0x7FFu) << nbits;  /* LSB first */
        nbits = (uint8_t)(nbits + 11u);
        while (nbits >= 8u) {
            out[o++] = (uint8_t)bits;
            bits >>= 8;
            nbits = (uint8_t)(nbits - 8u);
        }
    }
}

void crsf_unpack_channels(const uint8_t in[22], uint16_t ch[16])
{
    uint32_t bits = 0;
    uint8_t nbits = 0, c = 0, i;
    for (i = 0; i < CRSF_RC_PAYLOAD_SIZE; i++) {
        bits |= (uint32_t)in[i] << nbits;
        nbits = (uint8_t)(nbits + 8u);
        while (nbits >= 11u && c < CRSF_NUM_CHANNELS) {
            ch[c++] = (uint16_t)(bits & 0x7FFu);
            bits >>= 11;
            nbits = (uint8_t)(nbits - 11u);
        }
    }
}

/* ======================================================= byte order I/O */
static uint16_t rd16(const uint8_t *p) { return (uint16_t)(((uint16_t)p[0] << 8) | p[1]); }
static uint32_t rd24(const uint8_t *p)
{ return ((uint32_t)p[0] << 16) | ((uint32_t)p[1] << 8) | p[2]; }
static uint32_t rd32(const uint8_t *p)
{ return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }
static void wr16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)(v >> 8); p[1] = (uint8_t)v; }
static void wr24(uint8_t *p, uint32_t v)
{ p[0] = (uint8_t)(v >> 16); p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)v; }
static void wr32(uint8_t *p, uint32_t v)
{ p[0] = (uint8_t)(v >> 24); p[1] = (uint8_t)(v >> 16); p[2] = (uint8_t)(v >> 8); p[3] = (uint8_t)v; }

/* ============================================================== decoders */
bool crsf_decode_rc_channels(const uint8_t *f, uint16_t ch[16])
{
    if (f[2] != CRSF_TYPE_RC_CHANNELS || crsf_payload_len(f) < CRSF_RC_PAYLOAD_SIZE)
        return false;
    crsf_unpack_channels(&f[3], ch);
    return true;
}

bool crsf_decode_link_stats(const uint8_t *f, crsf_link_stats_t *ls)
{
    const uint8_t *p = &f[3];
    if (f[2] != CRSF_TYPE_LINK_STATS || crsf_payload_len(f) < 10u) return false;
    ls->up_rssi_ant1   = p[0];
    ls->up_rssi_ant2   = p[1];
    ls->up_lq          = p[2];
    ls->up_snr         = (int8_t)p[3];
    ls->active_antenna = p[4];
    ls->rf_profile     = p[5];
    ls->up_rf_power    = p[6];
    ls->down_rssi      = p[7];
    ls->down_lq        = p[8];
    ls->down_snr       = (int8_t)p[9];
    return true;
}

bool crsf_decode_battery(const uint8_t *f, crsf_battery_t *b)
{
    const uint8_t *p = &f[3];
    if (f[2] != CRSF_TYPE_BATTERY || crsf_payload_len(f) < 8u) return false;
    b->voltage_dv   = rd16(&p[0]);
    b->current_da   = rd16(&p[2]);
    b->capacity_mah = rd24(&p[4]);
    b->remaining    = p[7];
    return true;
}

bool crsf_decode_device_info(const uint8_t *f, crsf_device_info_t *info)
{
    const uint8_t *p = crsf_ext_payload(f);
    uint8_t n = crsf_ext_payload_len(f), i = 0, copy;
    if (f[2] != CRSF_TYPE_DEVICE_INFO) return false;
    while (i < n && p[i] != 0u) i++;                  /* end of name string */
    if (i >= n || (uint8_t)(n - i - 1u) < 14u) return false;
    copy = (i < CRSF_DEVICE_NAME_MAX) ? i : (uint8_t)(CRSF_DEVICE_NAME_MAX - 1u);
    memcpy(info->name, p, copy);
    info->name[copy] = '\0';
    p += i + 1u;
    info->serial        = rd32(&p[0]);
    info->hw_id         = rd32(&p[4]);
    info->fw_id         = rd32(&p[8]);
    info->param_count   = p[12];
    info->param_version = p[13];
    return true;
}

uint16_t crsf_rf_power_mw(uint8_t index)
{
    static const uint16_t mw[] = { 0, 10, 25, 100, 500, 1000, 2000, 250, 50 };
    return (index < sizeof(mw) / sizeof(mw[0])) ? mw[index] : 0u;
}

/* ============================================================== encoders */
uint8_t crsf_encode_frame(uint8_t *out, uint8_t sync, uint8_t type,
                          const uint8_t *payload, uint8_t len)
{
    if (len > CRSF_PAYLOAD_MAX) return 0;
    out[0] = sync;
    out[1] = (uint8_t)(len + 2u);                      /* type + payload + crc */
    out[2] = type;
    if (len) memcpy(&out[3], payload, len);
    out[3u + len] = crsf_crc8(&out[2], (size_t)len + 1u);
    return (uint8_t)(len + 4u);
}

uint8_t crsf_encode_ext_frame(uint8_t *out, uint8_t sync, uint8_t type,
                              uint8_t dest, uint8_t orig,
                              const uint8_t *payload, uint8_t len)
{
    uint8_t tmp[CRSF_PAYLOAD_MAX];
    if (len > CRSF_EXT_PAYLOAD_MAX) return 0;
    tmp[0] = dest;
    tmp[1] = orig;
    if (len) memcpy(&tmp[2], payload, len);
    return crsf_encode_frame(out, sync, type, tmp, (uint8_t)(len + 2u));
}

uint8_t crsf_encode_command(uint8_t *out, uint8_t sync, uint8_t dest, uint8_t orig,
                            uint8_t cmd, const uint8_t *payload, uint8_t len)
{
    /* extended payload = [cmd][payload ...][cmd_crc]
     * cmd_crc (poly 0xBA) covers: type 0x32, dest, orig, cmd, payload */
    uint8_t tmp[4u + CRSF_EXT_PAYLOAD_MAX];
    uint8_t n;
    if ((unsigned)len + 2u > CRSF_EXT_PAYLOAD_MAX) return 0;
    tmp[0] = CRSF_TYPE_COMMAND;
    tmp[1] = dest;
    tmp[2] = orig;
    tmp[3] = cmd;
    if (len) memcpy(&tmp[4], payload, len);
    n = (uint8_t)(4u + len);
    tmp[n] = crsf_crc8_cmd(tmp, n);
    return crsf_encode_ext_frame(out, sync, CRSF_TYPE_COMMAND, dest, orig,
                                 &tmp[3], (uint8_t)(len + 2u));
}

uint8_t crsf_encode_rc_channels(uint8_t *out, uint8_t sync, const uint16_t ch[16])
{
    uint8_t packed[CRSF_RC_PAYLOAD_SIZE];
    crsf_pack_channels(ch, packed);
    return crsf_encode_frame(out, sync, CRSF_TYPE_RC_CHANNELS, packed, CRSF_RC_PAYLOAD_SIZE);
}

uint8_t crsf_encode_link_stats(uint8_t *out, const crsf_link_stats_t *ls)
{
    uint8_t p[10];
    p[0] = ls->up_rssi_ant1;   p[1] = ls->up_rssi_ant2;
    p[2] = ls->up_lq;          p[3] = (uint8_t)ls->up_snr;
    p[4] = ls->active_antenna; p[5] = ls->rf_profile;
    p[6] = ls->up_rf_power;    p[7] = ls->down_rssi;
    p[8] = ls->down_lq;        p[9] = (uint8_t)ls->down_snr;
    return crsf_encode_frame(out, CRSF_SYNC_BYTE, CRSF_TYPE_LINK_STATS, p, 10);
}

uint8_t crsf_encode_battery(uint8_t *out, const crsf_battery_t *b)
{
    uint8_t p[8];
    wr16(&p[0], b->voltage_dv);
    wr16(&p[2], b->current_da);
    wr24(&p[4], b->capacity_mah);
    p[7] = b->remaining;
    return crsf_encode_frame(out, CRSF_SYNC_BYTE, CRSF_TYPE_BATTERY, p, 8);
}

uint8_t crsf_encode_gps(uint8_t *out, const crsf_gps_t *g)
{
    uint8_t p[15];
    int32_t alt = g->altitude_m + 1000;                /* +1000 m offset */
    if (alt < 0) alt = 0;
    if (alt > 0xFFFF) alt = 0xFFFF;
    wr32(&p[0], (uint32_t)g->lat_e7);
    wr32(&p[4], (uint32_t)g->lon_e7);
    wr16(&p[8], g->speed_dkmh);
    wr16(&p[10], g->heading_cdeg);
    wr16(&p[12], (uint16_t)alt);
    p[14] = g->satellites;
    return crsf_encode_frame(out, CRSF_SYNC_BYTE, CRSF_TYPE_GPS, p, 15);
}

uint8_t crsf_encode_vario(uint8_t *out, int16_t vspeed_cms)
{
    uint8_t p[2];
    wr16(p, (uint16_t)vspeed_cms);
    return crsf_encode_frame(out, CRSF_SYNC_BYTE, CRSF_TYPE_VARIO, p, 2);
}

uint8_t crsf_encode_attitude(uint8_t *out, int16_t pitch, int16_t roll, int16_t yaw)
{
    uint8_t p[6];
    wr16(&p[0], (uint16_t)pitch);
    wr16(&p[2], (uint16_t)roll);
    wr16(&p[4], (uint16_t)yaw);
    return crsf_encode_frame(out, CRSF_SYNC_BYTE, CRSF_TYPE_ATTITUDE, p, 6);
}

uint8_t crsf_encode_flight_mode(uint8_t *out, const char *mode)
{
    uint8_t p[CRSF_PAYLOAD_MAX];
    uint8_t n = 0;
    while (mode[n] != '\0' && n < CRSF_PAYLOAD_MAX - 1u) { p[n] = (uint8_t)mode[n]; n++; }
    p[n++] = 0;                                        /* null terminated */
    return crsf_encode_frame(out, CRSF_SYNC_BYTE, CRSF_TYPE_FLIGHT_MODE, p, n);
}

uint8_t crsf_encode_ping(uint8_t *out, uint8_t sync, uint8_t dest, uint8_t orig)
{
    return crsf_encode_ext_frame(out, sync, CRSF_TYPE_PING, dest, orig, NULL, 0);
}

uint8_t crsf_encode_device_info(uint8_t *out, uint8_t sync, uint8_t dest, uint8_t orig,
                                const crsf_device_info_t *info)
{
    uint8_t p[CRSF_EXT_PAYLOAD_MAX];
    uint8_t n = 0;
    while (n < CRSF_DEVICE_NAME_MAX - 1u && info->name[n] != '\0') {
        p[n] = (uint8_t)info->name[n];
        n++;
    }
    p[n++] = 0;
    wr32(&p[n], info->serial); n = (uint8_t)(n + 4u);
    wr32(&p[n], info->hw_id);  n = (uint8_t)(n + 4u);
    wr32(&p[n], info->fw_id);  n = (uint8_t)(n + 4u);
    p[n++] = info->param_count;
    p[n++] = info->param_version;
    return crsf_encode_ext_frame(out, sync, CRSF_TYPE_DEVICE_INFO, dest, orig, p, n);
}

uint8_t crsf_encode_param_read(uint8_t *out, uint8_t sync, uint8_t dest, uint8_t orig,
                               uint8_t param, uint8_t chunk)
{
    uint8_t p[2];
    p[0] = param;
    p[1] = chunk;
    return crsf_encode_ext_frame(out, sync, CRSF_TYPE_PARAM_READ, dest, orig, p, 2);
}
