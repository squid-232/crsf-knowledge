/**
 * crsf.h - Minimal, portable CRSF (Crossfire Serial Protocol) library
 *
 * Reference implementation for learning / prototyping. Based on:
 *   - TBS CRSF Protocol Specification  https://github.com/tbs-fpv/tbs-crsf-spec
 *   - Behaviour of ExpressLRS / Betaflight (420000 baud RX<->FC, 0.1 V battery units, ...)
 *
 * Features
 *   - C99, no malloc, no OS/HAL dependency, ISR friendly
 *   - stream parser: sync filter + length check + CRC8 + timeout + resync
 *   - pack/unpack of the 16 x 11 bit RC channels
 *   - encoders/decoders for common telemetry and extended frames
 *
 * Frame layout
 *   broadcast : [sync][len][type][payload ...][crc]
 *   extended  : [sync][len][type][dest][orig][payload ...][crc]
 *   len = number of bytes after the len field (type + payload + crc), valid 2..62
 *   crc = CRC-8, poly 0xD5, init 0, over type + payload (NOT sync, NOT len)
 *   multi-byte fields are big endian (only the RC channel bit packing is LSB first)
 *
 * License: MIT
 */
#ifndef CRSF_H
#define CRSF_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------ limits */
#define CRSF_FRAME_SIZE_MAX      64u  /* whole frame, sync .. crc             */
#define CRSF_LEN_MIN              2u  /* len field minimum: type + crc        */
#define CRSF_LEN_MAX             62u  /* len field maximum: 64 - sync - len   */
#define CRSF_PAYLOAD_MAX         60u  /* broadcast payload (64 - 4)           */
#define CRSF_EXT_PAYLOAD_MAX     58u  /* extended payload  (64 - 6)           */

/* -------------------------------------------------------------- baud rates */
#define CRSF_BAUD_SPEC_RX_FC  416666u /* TBS spec, RX <-> FC                  */
#define CRSF_BAUD_ELRS_RX     420000u /* ExpressLRS default, RX <-> FC        */
#define CRSF_BAUD_HANDSET     400000u /* TBS default, handset <-> TX module   */

/* --------------------------------------------------------------- addresses */
#define CRSF_ADDR_BROADCAST    0x00u
#define CRSF_ADDR_USB          0x10u
#define CRSF_ADDR_BT_WIFI      0x12u
#define CRSF_ADDR_OSD          0x80u
#define CRSF_ADDR_ESC_1        0x90u
#define CRSF_ADDR_CURRENT      0xC0u  /* voltage / current sensor            */
#define CRSF_ADDR_GPS          0xC2u
#define CRSF_ADDR_BLACKBOX     0xC4u
#define CRSF_ADDR_FC           0xC8u  /* flight controller                   */
#define CRSF_ADDR_VTX          0xCEu
#define CRSF_ADDR_RADIO        0xEAu  /* remote control / handset            */
#define CRSF_ADDR_RX           0xECu  /* receiver                            */
#define CRSF_ADDR_TX           0xEEu  /* transmitter module                  */
#define CRSF_SYNC_BYTE         0xC8u  /* default sync byte                   */

/* ------------------------------------------------------------- frame types */
/* broadcast frames: no dest / orig */
#define CRSF_TYPE_GPS          0x02u
#define CRSF_TYPE_VARIO        0x07u
#define CRSF_TYPE_BATTERY      0x08u
#define CRSF_TYPE_BARO_ALT     0x09u
#define CRSF_TYPE_HEARTBEAT    0x0Bu
#define CRSF_TYPE_LINK_STATS   0x14u
#define CRSF_TYPE_RC_CHANNELS  0x16u
#define CRSF_TYPE_SUBSET_RC    0x17u
#define CRSF_TYPE_LINK_RX_ID   0x1Cu
#define CRSF_TYPE_LINK_TX_ID   0x1Du
#define CRSF_TYPE_ATTITUDE     0x1Eu
#define CRSF_TYPE_FLIGHT_MODE  0x21u
/* extended frames: [dest][orig] follow the type byte */
#define CRSF_TYPE_PING         0x28u
#define CRSF_TYPE_DEVICE_INFO  0x29u
#define CRSF_TYPE_PARAM_ENTRY  0x2Bu
#define CRSF_TYPE_PARAM_READ   0x2Cu
#define CRSF_TYPE_PARAM_WRITE  0x2Du
#define CRSF_TYPE_COMMAND      0x32u
#define CRSF_TYPE_RADIO_ID     0x3Au
#define CRSF_TYPE_MSP_REQ      0x7Au
#define CRSF_TYPE_MSP_RESP     0x7Bu

/* Rule of thumb from the spec: types >= 0x28 are extended (carry dest/orig).
 * Known exceptions with the short (broadcast) header: 0x34 logging,
 * 0x80 ArduPilot passthrough, 0x81/0x82 mLRS, 0xAA MAVLink envelope.
 * Always check the spec entry of other vendor specific types. */
static inline bool crsf_is_extended(uint8_t t)
{
    return t >= 0x28u && t != 0x34u && (t < 0x80u || t > 0x82u) && t != 0xAAu;
}
#define CRSF_IS_EXTENDED(type) crsf_is_extended((uint8_t)(type))

/* -------------------------------------------- 0x32 command ids (subset) */
#define CRSF_CMD_FC            0x01u
#define CRSF_CMD_OSD           0x05u
#define CRSF_CMD_VTX           0x08u
#define CRSF_CMD_LED           0x09u
#define CRSF_CMD_GENERAL       0x0Au  /* 0x70 speed proposal / 0x71 response */
#define CRSF_CMD_CROSSFIRE     0x10u  /* 0x01 bind, 0x02 cancel bind, ...    */
#define CRSF_CMD_ACK           0xFFu

/* ------------------------------------------------------------ RC channels */
#define CRSF_NUM_CHANNELS      16u
#define CRSF_RC_PAYLOAD_SIZE   22u    /* 16 x 11 bit                          */
#define CRSF_CH_MIN            172u   /*  988 us (ExpressLRS / Betaflight)    */
#define CRSF_CH_MID            992u   /* 1500 us                              */
#define CRSF_CH_MAX            1811u  /* 2012 us                              */
/* conversions as given in the TBS spec (integer math, truncates toward 0) */
#define CRSF_TICKS_TO_US(x)  (((((int32_t)(x)) - 992) * 5) / 8 + 1500)
#define CRSF_US_TO_TICKS(x)  (((((int32_t)(x)) - 1500) * 8) / 5 + 992)

/* ---------------------------------------------------------------- structs */
typedef struct {
    uint8_t up_rssi_ant1;   /* uplink RSSI antenna 1, dBm * -1 (60 = -60 dBm) */
    uint8_t up_rssi_ant2;   /* uplink RSSI antenna 2, dBm * -1                */
    uint8_t up_lq;          /* uplink link quality, 0..100 %                  */
    int8_t  up_snr;         /* uplink SNR, dB                                 */
    uint8_t active_antenna; /* 0 = antenna 1, 1 = antenna 2                   */
    uint8_t rf_profile;     /* rate / mode index - meaning is vendor specific */
    uint8_t up_rf_power;    /* TX power index, see crsf_rf_power_mw()         */
    uint8_t down_rssi;      /* downlink (telemetry) RSSI, dBm * -1            */
    uint8_t down_lq;        /* downlink link quality, %                       */
    int8_t  down_snr;       /* downlink SNR, dB                               */
} crsf_link_stats_t;

typedef struct {
    uint16_t voltage_dv;    /* 0.1 V (Betaflight / ExpressLRS / EdgeTX usage) */
    uint16_t current_da;    /* 0.1 A                                          */
    uint32_t capacity_mah;  /* used capacity, 24 bit on the wire              */
    uint8_t  remaining;     /* remaining, %                                   */
} crsf_battery_t;

typedef struct {
    int32_t  lat_e7;        /* degree * 1e7                                   */
    int32_t  lon_e7;        /* degree * 1e7                                   */
    uint16_t speed_dkmh;    /* ground speed, 0.1 km/h (Betaflight practice)   */
    uint16_t heading_cdeg;  /* degree * 100                                   */
    int32_t  altitude_m;    /* metres; the encoder adds the +1000 m offset    */
    uint8_t  satellites;
} crsf_gps_t;

#define CRSF_DEVICE_NAME_MAX 44u   /* 58 - 14 fixed bytes, including '\0'   */
typedef struct {
    char     name[CRSF_DEVICE_NAME_MAX];
    uint32_t serial;        /* ExpressLRS reports 0x454C5253 ("ELRS")         */
    uint32_t hw_id;
    uint32_t fw_id;
    uint8_t  param_count;
    uint8_t  param_version;
} crsf_device_info_t;

/* ------------------------------------------------------------------ parser */
/* Called for every complete frame with a valid CRC. 'frame' points to
 * [sync][len][type]...[crc] and is only valid during the callback. */
typedef void (*crsf_frame_cb_t)(void *user, const uint8_t *frame, uint8_t frame_len);

typedef struct {
    uint8_t         buf[CRSF_FRAME_SIZE_MAX];
    uint8_t         pos;
    uint8_t         sync_map[32];   /* bitmap of accepted sync bytes          */
    uint32_t        frame_start_us;
    uint32_t        timeout_us;     /* 0 = disabled                           */
    crsf_frame_cb_t on_frame;
    void           *user;
    /* statistics */
    uint32_t        frames_ok;
    uint32_t        crc_errors;
    uint32_t        len_errors;
    uint32_t        timeouts;
} crsf_parser_t;

/* baud: used to derive the partial-frame timeout (0 -> 420000). Accepts 0xC8
 * as sync byte; add more with crsf_parser_accept() (e.g. 0xEA on a handset,
 * 0xEE on a TX module). */
void crsf_parser_init(crsf_parser_t *p, uint32_t baud, crsf_frame_cb_t cb, void *user);
void crsf_parser_accept(crsf_parser_t *p, uint8_t sync);
/* Feed received bytes. now_us = (ideally) arrival time of this chunk. */
void crsf_parser_feed(crsf_parser_t *p, const uint8_t *data, size_t len, uint32_t now_us);

/* ---------------------------------------------------------- frame helpers */
static inline uint8_t crsf_frame_type(const uint8_t *f)  { return f[2]; }
static inline uint8_t crsf_frame_size(const uint8_t *f)  { return (uint8_t)(f[1] + 2u); }
static inline const uint8_t *crsf_payload(const uint8_t *f) { return &f[3]; }
static inline uint8_t crsf_payload_len(const uint8_t *f)
{ return (uint8_t)(f[1] >= 2u ? f[1] - 2u : 0u); }
static inline uint8_t crsf_ext_dest(const uint8_t *f)    { return f[3]; }
static inline uint8_t crsf_ext_orig(const uint8_t *f)    { return f[4]; }
static inline const uint8_t *crsf_ext_payload(const uint8_t *f) { return &f[5]; }
static inline uint8_t crsf_ext_payload_len(const uint8_t *f)
{ return (uint8_t)(f[1] >= 4u ? f[1] - 4u : 0u); }

/* -------------------------------------------------------------------- CRC */
uint8_t crsf_crc8(const uint8_t *data, size_t len);      /* poly 0xD5          */
uint8_t crsf_crc8_cmd(const uint8_t *data, size_t len);  /* poly 0xBA (0x32)   */
/* true if buf[0..len-1] is exactly one well-formed frame with a valid CRC */
bool    crsf_frame_check(const uint8_t *buf, size_t len);

/* ----------------------------------------------------------- RC channels */
void crsf_pack_channels(const uint16_t ch[16], uint8_t out[22]);
void crsf_unpack_channels(const uint8_t in[22], uint16_t ch[16]);

/* --------------------------------------------- decoders (frame = sync..crc)
 * Return false if the type does not match or the payload is too short.
 * Longer payloads are accepted (extra fields are ignored, as the spec asks). */
bool crsf_decode_rc_channels(const uint8_t *frame, uint16_t ch[16]);
bool crsf_decode_link_stats(const uint8_t *frame, crsf_link_stats_t *ls);
bool crsf_decode_battery(const uint8_t *frame, crsf_battery_t *bat);
bool crsf_decode_device_info(const uint8_t *frame, crsf_device_info_t *info);
uint16_t crsf_rf_power_mw(uint8_t index);   /* 0x14 up_rf_power -> mW */

/* ---------------------------------------- encoders (out >= 64 bytes)
 * Return the total frame size in bytes, or 0 if the payload is too long. */
uint8_t crsf_encode_frame(uint8_t *out, uint8_t sync, uint8_t type,
                          const uint8_t *payload, uint8_t len);
uint8_t crsf_encode_ext_frame(uint8_t *out, uint8_t sync, uint8_t type,
                              uint8_t dest, uint8_t orig,
                              const uint8_t *payload, uint8_t len);
/* 0x32 direct command: payload = sub command + data; adds the inner command CRC */
uint8_t crsf_encode_command(uint8_t *out, uint8_t sync, uint8_t dest, uint8_t orig,
                            uint8_t cmd, const uint8_t *payload, uint8_t len);
uint8_t crsf_encode_rc_channels(uint8_t *out, uint8_t sync, const uint16_t ch[16]);
uint8_t crsf_encode_link_stats(uint8_t *out, const crsf_link_stats_t *ls);
uint8_t crsf_encode_battery(uint8_t *out, const crsf_battery_t *bat);
uint8_t crsf_encode_gps(uint8_t *out, const crsf_gps_t *gps);
uint8_t crsf_encode_vario(uint8_t *out, int16_t vspeed_cms);
/* attitude in 100 urad units (rad * 10000), range +-180 deg */
uint8_t crsf_encode_attitude(uint8_t *out, int16_t pitch, int16_t roll, int16_t yaw);
uint8_t crsf_encode_flight_mode(uint8_t *out, const char *mode);
uint8_t crsf_encode_ping(uint8_t *out, uint8_t sync, uint8_t dest, uint8_t orig);
uint8_t crsf_encode_device_info(uint8_t *out, uint8_t sync, uint8_t dest, uint8_t orig,
                                const crsf_device_info_t *info);
uint8_t crsf_encode_param_read(uint8_t *out, uint8_t sync, uint8_t dest, uint8_t orig,
                               uint8_t param, uint8_t chunk);

#ifdef __cplusplus
}
#endif

#endif /* CRSF_H */
