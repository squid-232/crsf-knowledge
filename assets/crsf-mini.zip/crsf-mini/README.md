# crsf-mini：CRSF 协议 C 参考实现（学习用）

基于 TBS《CRSF Protocol Specification》并参考 ExpressLRS / Betaflight 的实际行为编写。
C99、无动态内存、无平台依赖，可直接放进 STM32 / ESP32 / RP2040 等工程。

## 文件
| 文件 | 说明 |
| --- | --- |
| crsf.h / crsf.c | 库本体：CRC8(0xD5/0xBA)、流式解析器、11bit 通道打包/解包、常用帧编解码 |
| test_crsf.c | 单元测试 + 测试向量（63 项检查） |
| examples/stm32_hal_dma.c | STM32 HAL：UART DMA 循环模式 + IDLE 事件接收 ELRS 接收机，UART 出错后自动重启接收 |
| examples/esp32_arduino.ino | ESP32 Arduino：读取通道、LQ/RSSI，打印并做失控判断 |
| tools/crsf_sniff.py | Python 抓包脚本：USB-TTL 抓取并解码 CRSF；`--selftest` 无需硬件 |

## 构建与测试（PC 上）
    make test
    python3 tools/crsf_sniff.py --selftest   # 抓包脚本自测
    # 或：gcc -std=c99 -Wall -Wextra -pedantic crsf.c test_crsf.c -o test_crsf && ./test_crsf

## 最小用法
    static void on_frame(void *user, const uint8_t *f, uint8_t len) {
        uint16_t ch[16];
        if (crsf_frame_type(f) == CRSF_TYPE_RC_CHANNELS && crsf_decode_rc_channels(f, ch)) {
            /* ch[i] 为 172..1811，CRSF_TICKS_TO_US(ch[i]) 转为 988..2011 us */
        }
    }
    crsf_parser_t p;
    crsf_parser_init(&p, 420000, on_frame, NULL);
    crsf_parser_feed(&p, rx_bytes, n, micros());   /* 在 UART/DMA 回调或主循环里调用 */

## 设计要点
- 解析器：Sync 过滤（默认 0xC8，可 crsf_parser_accept() 增加 0xEA/0xEE）→ Len 2..62 → CRC
  → 回调；出错只丢 1 字节再重扫，被“假 Sync”吞掉的真帧可以找回；帧内超时（默认最大帧
  时长 +15%）后会先抢救缓冲区内的完整帧再丢弃残帧。timeout_us = 0 可关闭超时。
- 回调里拿到的 frame 指针只在回调期间有效；回调可能运行在中断上下文，请保持简短。
- 电池帧按 Betaflight/ELRS 实际用法：电压 0.1 V、电流 0.1 A、容量 mAh(24bit)、剩余 %。
- 0x14 链路统计里的 rf_profile 含义因厂商而异（ELRS 用自己的速率索引）。

License: MIT
