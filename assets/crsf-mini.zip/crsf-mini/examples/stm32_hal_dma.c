/**
 * stm32_hal_dma.c - CRSF receiver input on STM32 (HAL), illustrative example
 *
 * ELRS / Crossfire RX  -> USART1, 420000 baud (TBS spec: 416666), 8N1,
 * NOT inverted, full duplex (RX.TX -> MCU.RX, RX.RX <- MCU.TX).
 *
 * CubeMX: USART1 async 420000 8N1, DMA RX channel in CIRCULAR mode,
 *         USART1 global interrupt enabled; TIM2 = free running 32 bit, 1 MHz.
 * Not part of the host test build - adapt handles and names to your board.
 */
#include "main.h"
#include "crsf.h"

extern UART_HandleTypeDef huart1;
extern TIM_HandleTypeDef  htim2;

#define RX_DMA_SIZE 128u
static uint8_t       rx_dma[RX_DMA_SIZE];
static uint16_t      rx_old;                 /* last processed DMA position */
static crsf_parser_t parser;

/* data shared with the main loop */
static volatile uint16_t rc_us[CRSF_NUM_CHANNELS];
static volatile uint32_t rc_last_ms;
static volatile uint8_t  link_lq, link_rssi_dbm_neg;

static void on_crsf_frame(void *user, const uint8_t *f, uint8_t len)
{
    (void)user; (void)len;
    switch (crsf_frame_type(f)) {
    case CRSF_TYPE_RC_CHANNELS: {
        uint16_t ch[CRSF_NUM_CHANNELS];
        uint32_t i;
        if (f[0] != CRSF_ADDR_FC) break;        /* RC frames to the FC use 0xC8 */
        if (!crsf_decode_rc_channels(f, ch)) break;
        for (i = 0; i < CRSF_NUM_CHANNELS; i++)
            rc_us[i] = (uint16_t)CRSF_TICKS_TO_US(ch[i]);
        rc_last_ms = HAL_GetTick();
        break;
    }
    case CRSF_TYPE_LINK_STATS: {
        crsf_link_stats_t ls;
        if (crsf_decode_link_stats(f, &ls)) {
            link_lq = ls.up_lq;
            link_rssi_dbm_neg = ls.active_antenna ? ls.up_rssi_ant2 : ls.up_rssi_ant1;
        }
        break;
    }
    default:
        break;                                  /* ignore unknown types */
    }
}

void crsf_input_start(void)
{
    crsf_parser_init(&parser, CRSF_BAUD_ELRS_RX, on_crsf_frame, NULL);
    HAL_TIM_Base_Start(&htim2);
    rx_old = 0;
    HAL_UARTEx_ReceiveToIdle_DMA(&huart1, rx_dma, RX_DMA_SIZE);
}

/* HAL calls this on IDLE line, DMA half transfer and DMA transfer complete.
 * In circular mode 'pos' is the current write position inside rx_dma[]. */
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t pos)
{
    uint32_t now = __HAL_TIM_GET_COUNTER(&htim2);   /* 1 MHz timestamp */
    if (huart != &huart1 || pos == rx_old) return;
    if (pos > rx_old) {
        crsf_parser_feed(&parser, &rx_dma[rx_old], (size_t)(pos - rx_old), now);
    } else {                                        /* wrapped around */
        crsf_parser_feed(&parser, &rx_dma[rx_old], (size_t)(RX_DMA_SIZE - rx_old), now);
        crsf_parser_feed(&parser, &rx_dma[0], pos, now);
    }
    rx_old = (pos == RX_DMA_SIZE) ? 0u : pos;
}

/* With DMA reception enabled, HAL treats every UART error (noise, framing,
 * overrun - e.g. while plugging in the receiver) as blocking and aborts the
 * reception. Restart it, otherwise CRSF input stops for good. */
void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart != &huart1 || huart->RxState != HAL_UART_STATE_READY) return;
    rx_old = 0;
    HAL_UARTEx_ReceiveToIdle_DMA(&huart1, rx_dma, RX_DMA_SIZE);
}

/* Send one telemetry frame (FC -> RX). The buffer must stay valid until the
 * DMA transfer is done, therefore it is static. */
bool crsf_send_battery(uint16_t mv, uint16_t ma, uint32_t mah, uint8_t pct)
{
    static uint8_t tx[CRSF_FRAME_SIZE_MAX];
    crsf_battery_t b;
    uint8_t n;
    if (huart1.gState != HAL_UART_STATE_READY) return false;  /* still busy */
    b.voltage_dv = (uint16_t)(mv / 100u);    /* 0.1 V */
    b.current_da = (uint16_t)(ma / 100u);    /* 0.1 A */
    b.capacity_mah = mah;
    b.remaining = pct;
    n = crsf_encode_battery(tx, &b);
    return HAL_UART_Transmit_DMA(&huart1, tx, n) == HAL_OK;
}

/* main loop helper: failsafe if no valid RC frame for too long */
bool crsf_rc_lost(uint32_t timeout_ms)
{
    return (HAL_GetTick() - rc_last_ms) > timeout_ms;
}
