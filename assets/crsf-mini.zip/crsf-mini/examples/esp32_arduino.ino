// esp32_arduino.ino - read CRSF from an ExpressLRS receiver with an ESP32 (Arduino core)
// Wiring (full duplex, not inverted): ELRS RX "TX" -> GPIO16, ELRS RX "RX" <- GPIO17, GND, 5V
// Copy crsf.h / crsf.c into the sketch folder.
#include <Arduino.h>
#include "crsf.h"

static crsf_parser_t parser;
static uint16_t ch[CRSF_NUM_CHANNELS];
static uint32_t lastRcMs;
static crsf_link_stats_t linkStats;

static void onFrame(void *user, const uint8_t *f, uint8_t len) {
  (void)user; (void)len;
  if (crsf_frame_type(f) == CRSF_TYPE_RC_CHANNELS && crsf_decode_rc_channels(f, ch)) {
    lastRcMs = millis();
  } else if (crsf_frame_type(f) == CRSF_TYPE_LINK_STATS) {
    crsf_decode_link_stats(f, &linkStats);
  }
}

void setup() {
  Serial.begin(115200);
  Serial1.begin(420000, SERIAL_8N1, /*rx=*/16, /*tx=*/17);
  crsf_parser_init(&parser, 420000, onFrame, nullptr);
  parser.timeout_us = 0;  // polled reads have no reliable arrival time: rely on CRC + resync
}

void loop() {
  uint8_t buf[64];
  size_t n = Serial1.available();
  if (n > sizeof(buf)) n = sizeof(buf);
  if (n) {
    n = Serial1.readBytes(buf, n);
    crsf_parser_feed(&parser, buf, n, micros());
  }

  static uint32_t lastPrint;
  if (millis() - lastPrint >= 200) {
    lastPrint = millis();
    if (millis() - lastRcMs > 1000) {
      Serial.println("FAILSAFE: no RC frames");
    } else {
      Serial.printf("CH1-4 %4ld %4ld %4ld %4ld us | ARM(CH5) %4ld | LQ %u%% RSSI -%u dBm\n",
                    (long)CRSF_TICKS_TO_US(ch[0]), (long)CRSF_TICKS_TO_US(ch[1]),
                    (long)CRSF_TICKS_TO_US(ch[2]), (long)CRSF_TICKS_TO_US(ch[3]),
                    (long)CRSF_TICKS_TO_US(ch[4]), linkStats.up_lq, linkStats.up_rssi_ant1);
    }
  }
}
