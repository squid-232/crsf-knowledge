#!/usr/bin/env python3
"""crsf_sniff.py - capture and decode CRSF frames with a USB-TTL adapter.

Usage:  python crsf_sniff.py COM5                  (Windows)
        python crsf_sniff.py /dev/ttyUSB0 420000   (Linux, baud optional)
        python crsf_sniff.py --selftest            (no hardware needed)
Wiring: receiver TX -> USB-TTL RX, common GND. Listen only, leave USB-TTL TX open.
Needs:  pip install pyserial   (Python 3.8+)
"""
import random
import sys
import time

SYNC = {0xC8, 0xEA, 0xEE, 0xEC, 0x00}


def crc8(data, poly=0xD5):
    crc = 0
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ poly) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


class Parser:
    """Sync -> Len (2..62) -> CRC; on error drop one byte and rescan."""

    def __init__(self):
        self.buf = bytearray()
        self.ok = 0
        self.bad = 0

    def feed(self, data):
        """Append bytes, return the list of complete frames with a valid CRC."""
        self.buf += data
        frames = []
        while len(self.buf) >= 2:
            if self.buf[0] not in SYNC or not 2 <= self.buf[1] <= 62:
                del self.buf[0]                    # not a frame start
                continue
            size = self.buf[1] + 2
            if len(self.buf) < size:
                break                              # wait for more bytes
            frame = bytes(self.buf[:size])
            if crc8(frame[2:-1]) == frame[-1]:
                self.ok += 1
                del self.buf[:size]
                frames.append(frame)
            else:
                self.bad += 1                      # also counts false sync bytes
                del self.buf[0]                    # resync from the next byte
        return frames

    def flush(self):
        """Line idle: nothing can still be incomplete -> drop stale header, rescan.
        Recovers real frames hidden behind a false sync (like the MCU timeout)."""
        frames = []
        while self.buf:
            del self.buf[0]
            frames += self.feed(b"")
        return frames


def u(p, a, n):
    return int.from_bytes(p[a:a + n], "big")


def s(p, a, n):
    return int.from_bytes(p[a:a + n], "big", signed=True)


def describe(frame):
    t, p = frame[2], frame[3:-1]
    if t == 0x16 and len(p) >= 22:
        v = int.from_bytes(p[:22], "little")       # 11-bit channels, LSB first
        us = [round(1500 + (((v >> (11 * i)) & 0x7FF) - 992) * 0.625) for i in range(16)]
        return "RC   " + " ".join(f"{x:4d}" for x in us[:8]) + "  (CH1-8, us)"
    if t == 0x14 and len(p) >= 10:
        return (f"LINK RSSI -{p[0]}/-{p[1]} dBm  LQ {p[2]}%  SNR {s(p, 3, 1)} dB  ANT {p[4]}  "
                f"RFMD {p[5]}  PWR {p[6]}  | TLM RSSI -{p[7]} dBm  LQ {p[8]}%  SNR {s(p, 9, 1)} dB")
    if t == 0x08 and len(p) >= 8:
        return f"BATT {u(p, 0, 2) / 10:.1f} V  {u(p, 2, 2) / 10:.1f} A  {u(p, 4, 3)} mAh  {p[7]}%"
    if t == 0x02 and len(p) >= 15:
        return (f"GPS  {s(p, 0, 4) / 1e7:.7f}, {s(p, 4, 4) / 1e7:.7f}  {u(p, 8, 2) / 10:.1f} km/h  "
                f"{u(p, 10, 2) / 100:.2f} deg  {u(p, 12, 2) - 1000} m  {p[14]} sats")
    if t == 0x1E and len(p) >= 6:
        deg = [s(p, i, 2) / 174.533 for i in (0, 2, 4)]
        return "ATT  pitch {:.1f}  roll {:.1f}  yaw {:.1f} deg".format(*deg)
    if t == 0x07 and len(p) >= 2:
        return f"VARIO {s(p, 0, 2)} cm/s"
    if t == 0x21:
        return "MODE " + p.split(b"\0")[0].decode("ascii", "replace")
    if t >= 0x28 and len(p) >= 2:
        return f"EXT  type 0x{t:02X} dest 0x{p[0]:02X} orig 0x{p[1]:02X}  " + frame.hex(" ")
    return f"T{t:02X}  " + frame.hex(" ")


def selftest():
    vectors = [
        "C8 18 16 E0 03 1F F8 C0 07 3E F0 81 0F 7C E0 03 1F F8 C0 07 3E F0 81 0F 7C AD",
        "C8 0C 14 3C 3E 64 09 00 07 03 37 64 0A DF",
        "C8 0A 08 00 A8 00 7B 00 04 D2 38 09",
        "C8 11 02 12 8D 10 07 48 64 D5 D2 02 0B 23 28 03 F7 0C BA",
        "C8 08 1E 06 D1 FC 97 7A B8 EE",
        "C8 04 07 FF 6A 34",
        "C8 07 21 41 43 52 4F 00 80",
        "EE 04 28 00 EA 54",
    ]
    rnd = random.Random(1)
    stream = bytearray()
    for v in vectors:                              # noise + false sync before each frame
        stream += bytes(rnd.getrandbits(8) for _ in range(5)) + b"\xC8\x30" + bytes.fromhex(v)
    p = Parser()
    frames = []
    for i in range(0, len(stream), 7):             # feed in odd-sized chunks
        frames += p.feed(stream[i:i + 7])
    frames += p.flush()                            # end of stream = idle line
    for frame in frames:
        print(describe(frame))
    print(f"--- {p.ok} frames ok ({len(vectors)} expected), {p.bad} CRC errors")


def main():
    if len(sys.argv) < 2 or sys.argv[1] == "--selftest":
        return selftest()
    import serial
    baud = int(sys.argv[2]) if len(sys.argv) > 2 else 420000
    ser = serial.Serial(sys.argv[1], baud, timeout=0.02)
    p = Parser()
    try:
        capture(ser, p)
    except KeyboardInterrupt:                      # Ctrl+C
        print(f"\n=== frames ok {p.ok}, CRC errors {p.bad}")


def capture(ser, p):
    last_stat = last_rx = time.time()
    last_rc = 0.0
    while True:
        data = ser.read(256)
        if data:
            last_rx = time.time()
            frames = p.feed(data)
        elif p.buf and time.time() - last_rx > 0.05:
            frames = p.flush()                     # line idle for 50 ms
        else:
            frames = []
        for frame in frames:
            if frame[2] == 0x16:                   # RC frames arrive at 50..1000 Hz:
                if time.time() - last_rc < 0.2:    # print at most 5 per second
                    continue
                last_rc = time.time()
            print(describe(frame))
        if time.time() - last_stat >= 1.0:
            last_stat = time.time()
            print(f"--- frames ok {p.ok}, CRC errors {p.bad}")


if __name__ == "__main__":
    main()
